
export const GEMINI_TEXT_MODEL = 'gemini-2.5-flash-preview-04-17';
export const IMAGEN_MODEL = 'imagen-3.0-generate-002';

export const MAX_STORY_HISTORY_FOR_PROMPT = 5; // Number of past events to include in Gemini prompt
