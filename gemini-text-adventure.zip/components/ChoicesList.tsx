
import React from 'react';
import ActionButton from './ActionButton';

interface ChoicesListProps {
  choices: string[];
  onSelectChoice: (choice: string) => void;
  isLoading: boolean;
}

const ChoicesList: React.FC<ChoicesListProps> = ({ choices, onSelectChoice, isLoading }) => {
  if (!choices || choices.length === 0) {
    return null;
  }

  return (
    <div className="w-full max-w-3xl mx-auto mt-6 md:mt-8">
      <h3 className="text-xl font-semibold text-purple-300 mb-4 text-center">What do you do?</h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {choices.map((choice, index) => (
          <ActionButton
            key={index}
            onClick={() => onSelectChoice(choice)}
            disabled={isLoading}
            className="text-sm md:text-base"
          >
            {choice}
          </ActionButton>
        ))}
      </div>
    </div>
  );
};

export default ChoicesList;
