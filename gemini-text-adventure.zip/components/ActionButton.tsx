
import React from 'react';

interface ActionButtonProps {
  onClick: () => void;
  disabled?: boolean;
  children: React.ReactNode;
  className?: string;
}

const ActionButton: React.FC<ActionButtonProps> = ({ onClick, disabled, children, className }) => {
  return (
    <button
      onClick={onClick}
      disabled={disabled}
      className={`
        bg-purple-600 hover:bg-purple-700 text-white font-semibold 
        py-3 px-6 rounded-lg shadow-md transition-all duration-200 ease-in-out 
        focus:outline-none focus:ring-2 focus:ring-purple-400 focus:ring-opacity-75
        disabled:bg-gray-500 disabled:cursor-not-allowed disabled:shadow-none
        transform hover:scale-105 active:scale-95
        ${className}
      `}
    >
      {children}
    </button>
  );
};

export default ActionButton;
