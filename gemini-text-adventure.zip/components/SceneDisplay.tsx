
import React from 'react';
import type { DisplayScene } from '../types';

interface SceneDisplayProps {
  scene: DisplayScene | null;
}

const SceneDisplay: React.FC<SceneDisplayProps> = ({ scene }) => {
  if (!scene) {
    return (
      <div className="text-center p-8 text-gray-400">
        The mists of creation are swirling...
      </div>
    );
  }

  return (
    <div className="w-full max-w-3xl mx-auto bg-gray-800 rounded-xl shadow-2xl overflow-hidden">
      {scene.imageUrl ? (
        <img
          src={scene.imageUrl}
          alt={scene.imagePrompt || 'Current scene visual'}
          className="w-full h-72 md:h-96 object-cover border-b-4 border-gray-700"
        />
      ) : (
        <div className="w-full h-72 md:h-96 bg-gray-700 flex items-center justify-center text-gray-500">
          <p>Generating vision...</p>
        </div>
      )}
      <div className="p-6 md:p-8">
        {/* Fix: Changed scene.description to scene.sceneDescription */}
        <p className="text-gray-200 text-lg leading-relaxed whitespace-pre-wrap font-serif">
          {scene.sceneDescription}
        </p>
      </div>
    </div>
  );
};

export default SceneDisplay;