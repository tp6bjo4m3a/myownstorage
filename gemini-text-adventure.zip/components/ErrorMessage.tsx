
import React from 'react';

interface ErrorMessageProps {
  message: string;
  onRetry?: () => void;
}

const ErrorMessage: React.FC<ErrorMessageProps> = ({ message, onRetry }) => {
  return (
    <div className="bg-red-900 border border-red-700 text-red-100 px-6 py-4 rounded-lg shadow-lg max-w-md mx-auto my-8" role="alert">
      <strong className="font-bold block text-lg">Oops! Something went wrong.</strong>
      <span className="block sm:inline mt-1">{message}</span>
      {onRetry && (
        <div className="mt-4">
          <button
            onClick={onRetry}
            className="bg-red-600 hover:bg-red-700 text-white font-semibold py-2 px-4 rounded-md transition-colors duration-150"
          >
            Try Again
          </button>
        </div>
      )}
    </div>
  );
};

export default ErrorMessage;
