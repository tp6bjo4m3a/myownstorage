
import React, { useState } from 'react';
import ActionButton from './ActionButton';

interface GameSetupProps {
  onStartGame: (theme: string) => void;
  isLoading: boolean;
}

const GameSetup: React.FC<GameSetupProps> = ({ onStartGame, isLoading }) => {
  const [theme, setTheme] = useState<string>('');
  const [showPlaceholder, setShowPlaceholder] = useState<boolean>(true);

  const popularThemes = [
    "A haunted mansion exploration",
    "Surviving on a deserted alien planet",
    "A cyberpunk detective in a futuristic city",
    "A fantasy quest for a legendary artifact",
    "A submarine adventure in uncharted waters"
  ];
  const [placeholder, setPlaceholder] = useState<string>(popularThemes[Math.floor(Math.random() * popularThemes.length)]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (theme.trim()) {
      onStartGame(theme.trim());
    } else {
      onStartGame(placeholder); // Start with placeholder if input is empty
    }
  };

  return (
    <div className="w-full max-w-lg mx-auto p-8 bg-gray-800 rounded-xl shadow-2xl">
      <h2 className="text-3xl font-bold text-center text-purple-300 mb-8">
        Begin Your Adventure
      </h2>
      <form onSubmit={handleSubmit} className="space-y-6">
        <div>
          <label htmlFor="theme" className="block text-sm font-medium text-gray-300 mb-1">
            Describe your desired adventure theme:
          </label>
          <div className="relative">
            <input
              type="text"
              id="theme"
              value={theme}
              onChange={(e) => {
                setTheme(e.target.value);
                setShowPlaceholder(e.target.value === '');
              }}
              onFocus={() => setShowPlaceholder(false)}
              onBlur={() => setShowPlaceholder(theme === '')}
              className="w-full px-4 py-3 bg-gray-700 border border-gray-600 rounded-lg text-gray-100 focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none transition-colors"
            />
            {showPlaceholder && (
               <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-500 pointer-events-none italic">
                 e.g., {placeholder}
               </span>
            )}
          </div>
           <p className="mt-2 text-xs text-gray-400">Or leave blank to use the suggested theme.</p>
        </div>
        {/* Fix: Removed 'type="submit"' prop as it's not part of ActionButtonProps */}
        <ActionButton disabled={isLoading} className="w-full">
          {isLoading ? 'Summoning World...' : 'Start Adventure!'}
        </ActionButton>
      </form>
    </div>
  );
};

export default GameSetup;