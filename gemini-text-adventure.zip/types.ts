
export interface RawSceneData {
  sceneDescription: string;
  imagePrompt: string;
  choices: string[];
}

export interface DisplayScene extends RawSceneData {
  id: string;
  imageUrl: string;
}

export interface StoryEvent {
  sceneDescription: string;
  playerChoice: string;
}

export type GameStatus = 'setup' | 'loading' | 'playing' | 'error';
