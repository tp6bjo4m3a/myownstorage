
import { GoogleGenAI, GenerateContentResponse } from "@google/genai";
import type { StoryEvent, RawSceneData } from '../types';
import { GEMINI_TEXT_MODEL, IMAGEN_MODEL, MAX_STORY_HISTORY_FOR_PROMPT } from '../constants';

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  console.error("API_KEY environment variable not set. AI features will not work.");
  // In a real app, you might throw an error or disable features.
  // For this exercise, we proceed, but API calls will fail if key is truly missing.
}

const ai = new GoogleGenAI({ apiKey: API_KEY || "MISSING_API_KEY" });

function parseJsonFromGeminiResponse(text: string): any {
  let jsonStr = text.trim();
  const fenceRegex = /^```(?:json)?\s*\n?(.*?)\n?\s*```$/s;
  const match = jsonStr.match(fenceRegex);
  if (match && match[1]) {
    jsonStr = match[1].trim();
  }
  try {
    return JSON.parse(jsonStr);
  } catch (e) {
    console.error("Failed to parse JSON response from Gemini:", e, "Raw text:", text);
    throw new Error("AI failed to provide a valid story structure. Please try again.");
  }
}

function formatStoryHistoryForPrompt(history: StoryEvent[]): string {
  if (history.length === 0) return "This is the beginning of the adventure.";
  
  return history
    .slice(-MAX_STORY_HISTORY_FOR_PROMPT)
    .map((event, index) => `Turn ${index + 1}:\nScene: ${event.sceneDescription}\nPlayer Chose: ${event.playerChoice}`)
    .join('\n\n');
}

export async function generateInitialScene(theme: string): Promise<RawSceneData> {
  const prompt = `
You are a creative text adventure game master.
Adventure Theme: "${theme}"

Generate the very first scene.
Your response MUST be a JSON object with the following structure:
{
  "sceneDescription": "A detailed and engaging starting scene description, around 100-150 words...",
  "imagePrompt": "A concise, artistic image prompt for this scene (e.g., 'mystical forest, ancient ruins, ethereal glow, concept art'). Focus on visual elements and mood.",
  "choices": ["Choice A (2-5 words)", "Choice B (2-5 words)", "Choice C (2-5 words)"]
}
Ensure choices are distinct and lead to interesting possibilities.
The sceneDescription should be vivid. ImagePrompt should be suitable for an image generation AI.
Choices should be short and actionable.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.8, // More creative
      },
    });
    const rawData = parseJsonFromGeminiResponse(response.text);
    if (!rawData.sceneDescription || !rawData.imagePrompt || !Array.isArray(rawData.choices) || rawData.choices.length === 0) {
        throw new Error("AI response missing required fields for initial scene.");
    }
    return rawData as RawSceneData;
  } catch (error) {
    console.error("Error generating initial scene:", error);
    throw new Error(`Failed to start adventure: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function generateNextScene(theme: string, storyHistory: StoryEvent[], playerChoice: string): Promise<RawSceneData> {
  const formattedHistory = formatStoryHistoryForPrompt(storyHistory);
  const prompt = `
You are a creative text adventure game master continuing an adventure.
Adventure Theme: "${theme}"

Story So Far:
${formattedHistory}

Player's Last Choice: "${playerChoice}"

Generate the next part of the adventure.
Your response MUST be a JSON object with the following structure:
{
  "sceneDescription": "A detailed and engaging new scene description (around 100-150 words), describing the consequences of the player's choice and the new situation...",
  "imagePrompt": "A concise, artistic image prompt for this new scene (e.g., 'underwater city, bioluminescent creatures, deep sea exploration, digital painting'). Focus on visual elements and mood.",
  "choices": ["New Choice X (2-5 words)", "New Choice Y (2-5 words)", "New Choice Z (2-5 words)"]
}
Ensure the new scene is a logical continuation. Choices should be relevant and offer diverse paths.
The sceneDescription should be vivid. ImagePrompt should be suitable for an image generation AI.
Choices should be short and actionable. If the story is naturally concluding, one choice could be 'The adventure ends here.' or similar.
`;

  try {
    const response: GenerateContentResponse = await ai.models.generateContent({
      model: GEMINI_TEXT_MODEL,
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        temperature: 0.7,
      },
    });
    const rawData = parseJsonFromGeminiResponse(response.text);
     if (!rawData.sceneDescription || !rawData.imagePrompt || !Array.isArray(rawData.choices) || rawData.choices.length === 0) {
        throw new Error("AI response missing required fields for next scene.");
    }
    return rawData as RawSceneData;
  } catch (error) {
    console.error("Error generating next scene:", error);
    throw new Error(`Failed to continue adventure: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export async function generateImage(prompt: string): Promise<string> {
  try {
    const response = await ai.models.generateImages({
      model: IMAGEN_MODEL,
      prompt: prompt,
      config: { numberOfImages: 1, outputMimeType: 'image/jpeg' },
    });

    if (response.generatedImages && response.generatedImages.length > 0 && response.generatedImages[0].image?.imageBytes) {
      const base64ImageBytes: string = response.generatedImages[0].image.imageBytes;
      return `data:image/jpeg;base64,${base64ImageBytes}`;
    } else {
      console.error("Imagen response missing image data:", response);
      throw new Error("AI failed to generate an image.");
    }
  } catch (error) {
    console.error("Error generating image:", error);
    // Provide a fallback or more specific error.
    if (error instanceof Error && error.message.includes("API_KEY_INVALID")) {
         throw new Error("Invalid API Key for image generation. Please check your configuration.");
    }
    throw new Error(`Failed to generate image: ${error instanceof Error ? error.message : String(error)}`);
  }
}
