
import React, { useState, useCallback, useEffect } from 'react';
import type { GameStatus, DisplayScene, StoryEvent, RawSceneData } from './types';
import { generateInitialScene, generateNextScene, generateImage } from './services/geminiService';

import GameSetup from './components/GameSetup';
import SceneDisplay from './components/SceneDisplay';
import ChoicesList from './components/ChoicesList';
import LoadingSpinner from './components/LoadingSpinner';
import ErrorMessage from './components/ErrorMessage';
import ActionButton from './components/ActionButton';

const App: React.FC = () => {
  const [gameStatus, setGameStatus] = useState<GameStatus>('setup');
  const [currentTheme, setCurrentTheme] = useState<string>('');
  const [currentScene, setCurrentScene] = useState<DisplayScene | null>(null);
  const [storyHistory, setStoryHistory] = useState<StoryEvent[]>([]);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const handleApiError = (error: unknown, retryCallback?: () => void) => {
    console.error("Game Error:", error);
    const message = error instanceof Error ? error.message : "An unknown error occurred.";
    // Check for API key specific error messages
    if (message.toLowerCase().includes("api key") || message.toLowerCase().includes("api_key")) {
         setErrorMessage("There's an issue with the AI configuration (API Key). Please ensure it's set up correctly. For developers: check environment variables.");
    } else {
        setErrorMessage(message);
    }
    setGameStatus('error');
    // If retryCallback is provided, App.tsx should handle setting status back to loading/playing.
  };
  
  const processSceneData = async (rawData: RawSceneData, sceneIdPrefix: string): Promise<DisplayScene> => {
    setGameStatus('loading'); // Explicitly set loading for image generation
    const imageUrl = await generateImage(rawData.imagePrompt);
    return {
      id: `${sceneIdPrefix}-${Date.now()}`,
      ...rawData,
      imageUrl,
    };
  };

  const startGame = useCallback(async (theme: string) => {
    setGameStatus('loading');
    setErrorMessage(null);
    setCurrentTheme(theme);
    setStoryHistory([]);
    setCurrentScene(null);

    try {
      const initialRawData = await generateInitialScene(theme);
      const scene = await processSceneData(initialRawData, 'initial');
      setCurrentScene(scene);
      setGameStatus('playing');
    } catch (error) {
      handleApiError(error, () => startGame(theme));
    }
  }, []);

  const selectChoice = useCallback(async (choice: string) => {
    if (!currentScene) return;

    setGameStatus('loading');
    setErrorMessage(null);

    const currentEvent: StoryEvent = {
      // Fix: Changed currentScene.description to currentScene.sceneDescription
      sceneDescription: currentScene.sceneDescription,
      playerChoice: choice,
    };
    const updatedHistory = [...storyHistory, currentEvent];
    setStoryHistory(updatedHistory);

    try {
      const nextRawData = await generateNextScene(currentTheme, updatedHistory, choice);
      const scene = await processSceneData(nextRawData, 'next');
      setCurrentScene(scene);
      setGameStatus('playing');
    } catch (error) {
      // Rollback history if next scene fails, or allow retry of this step.
      // For simplicity, just show error. User can retry from previous state by making a choice again (if applicable) or restarting.
      handleApiError(error, () => selectChoice(choice)); // This could re-submit the same choice
    }
  }, [currentScene, storyHistory, currentTheme]);

  const restartGame = () => {
    setGameStatus('setup');
    setCurrentScene(null);
    setStoryHistory([]);
    setCurrentTheme('');
    setErrorMessage(null);
  };
  
  // Effect to show loading message during API calls
  useEffect(() => {
    if (gameStatus === 'loading' && !currentScene) {
        // Initial load message handled by GameSetup
    } else if (gameStatus === 'loading' && currentScene) {
        // Subsequent loads have a different message
    }
  }, [gameStatus, currentScene]);


  return (
    <div className="bg-gray-900 text-gray-100 min-h-screen flex flex-col items-center justify-center p-4 font-sans selection:bg-purple-500 selection:text-white">
      <header className="w-full max-w-4xl mx-auto mb-8 text-center">
        <h1 className="text-4xl md:text-5xl font-bold text-transparent bg-clip-text bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 py-2">
          Gemini Text Adventure
        </h1>
      </header>

      <main className="w-full max-w-4xl mx-auto">
        {gameStatus === 'setup' && (
          <GameSetup onStartGame={startGame} isLoading={false} /> // isLoading here is for the button text, actual loading handled by gameStatus
        )}

        {gameStatus === 'loading' && (
           <LoadingSpinner message={currentScene ? "The story unfolds..." : "Summoning world..."} />
        )}

        {gameStatus === 'error' && errorMessage && (
          <div className="flex flex-col items-center">
            <ErrorMessage message={errorMessage} />
            <ActionButton onClick={restartGame} className="mt-4">
              Restart Adventure
            </ActionButton>
          </div>
        )}

        {gameStatus === 'playing' && currentScene && (
          <>
            <SceneDisplay scene={currentScene} />
            <ChoicesList
              choices={currentScene.choices}
              onSelectChoice={selectChoice}
              isLoading={false} // Button disabled state is handled by overall gameStatus if needed, here just pass false
            />
             <div className="mt-8 text-center">
                <ActionButton onClick={restartGame} className="bg-red-600 hover:bg-red-700">
                 Start New Adventure
                </ActionButton>
            </div>
          </>
        )}
      </main>
      
      <footer className="w-full max-w-4xl mx-auto mt-12 text-center text-sm text-gray-500 pb-4">
        <p>Powered by Gemini & Imagen. Your choices shape the world.</p>
        {storyHistory.length > 0 && (
            <p className="mt-1">Turns taken: {storyHistory.length}</p>
        )}
      </footer>
    </div>
  );
};

export default App;